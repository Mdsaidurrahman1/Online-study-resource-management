@extends('admin.admintemplate')

@section('content')
<div class="contentsection">
<h1> News and Notice</h1>
                @if (Session::has('message'))
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> {{Session::get('message') }}    
                  </div>
                @endif
<button class="btn btn-success">Create</button> <hr>

<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
      <th scope="col" style="width: 30%; text-align: right;">Handle</th>
    </tr>
  </thead>
  <tbody>

          @php $i = 1 @endphp
            @foreach ($message as $msg)
            <tr>
              <td scope="row">  @php echo  $i++ ;  @endphp  </td>
              <td> {{ $msg->Sender_name }}</td>
              <td> {{ $msg->Message_subject }}</td>
              <td>{{ $msg->Sender_email }} <br>{{ $msg->Sender_contact }}</td>
              <td>{{ $msg->Type }}</td>
              <td>{{ $msg->Message }}</td>
              <td>{{ $msg->created_at }}</td>
              <td style="text-align: right;">
                <a href="{{url('/messagedelete/'.$msg->id)}}" class="btn btn-sm btn-danger"> Delete </a>
              </td>
            </tr>

            @endforeach
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
      <td style="width: 30%; text-align: right;">
      	<a href="" class="btn btn-sm btn-info"> Detail </a>
      	<a href="" class="btn btn-sm btn-warning"> Delete </a>
      	<a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
      <td style="width: 30%; text-align: right;">
      	<a href="" class="btn btn-sm btn-info"> Detail </a>
      	<a href="" class="btn btn-sm btn-warning"> Delete </a>
      	<a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
      <td style="width: 30%; text-align: right;"">
      	<a href="" class="btn btn-sm btn-info"> Detail </a>
      	<a href="" class="btn btn-sm btn-warning"> Delete </a>
      	<a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
  </tbody>
</table>
</div>


@endsection

