@extends('template')

@section('content')
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p><span style="font-size: 24px;color="red"> Service Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-3 menu">
              <a href="{{route('admin_news')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Message</a> 
              <a href="{{route('admin_service')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-home"> </i> Service</a> 
              <a href="{{route('admin_work')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Work</a> 
              <a href="{{route('admin_content')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Content Management</a>
             
          </div>

          <div class="col-md-3 sideform">

           <div class="contentsection">
              
                  @if (Session::has('message'))
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> {{Session::get('message') }}    
                  </div>
                  @endif

                <h4> Service Update</h4>

                 <form action="{{route('servicepost')}}" method="post" enctype="multipart/form-data">
                        @csrf
                    <div class="form-group">
                      <label for="exampleInputEmail1">Service Name</label>
                      <input type="text" class="form-control" id="servicename" name="servicename" aria-describedby="emailHelp" placeholder="Enter Service Name">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea name="servicedesc" class="form-control"></textarea>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Price</label>
                      <input type="number" class="form-control" id="serviceprice" name="serviceprice" aria-describedby="emailHelp" placeholder="Enter Service price">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Offer</label>
                      <input type="text" class="form-control" id="servicoffer" name="servicoffer" aria-describedby="emailHelp" placeholder="Applicable offer">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Select picture</label>
                      <input type="file" id="servicpicutre" name="servicpicture" aria-describedby="emailHelp" placeholder="Applicable offer">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>

              </div>


          </div>

    </div>

  </section>



@endsection


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>



