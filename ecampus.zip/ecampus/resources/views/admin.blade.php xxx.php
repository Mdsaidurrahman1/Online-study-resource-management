@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">

            <p class="subtitle" > {{ Session::get('username')}}<br>
             {{ Session::get('userrole')}} <br>
             {{ Session::get('institution')}} 
           </p>
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Add New Class</a> 
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Upload Resource</a> 
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Set Assignment</a>
          </div>

          <div class="col-md-10">

            <h4> Professor Panel <h4>



           <div class="row">
              <div class="col-md-4">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Assignment</div>
                  <div class="panel-body">
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#Acc"> Set Assignment</button> <hr>

                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">ID</th>
                              <th scope="col">Title</th>
                              <th scope="col">Deadline</th>
                          </tr>
                        </thead>
                          <tbody>
                            <tr>
                              
                            </tr>
                              <td >CSE101-bd</td>
                              <td >Class Test</td>
                              <td >15 March</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Detail</a></td>

                            </tr>
                          </tr>
                              <td >CSE101-bd</td>
                              <td >Presentation</td>
                              <td >20 March</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Detail</a></td>

                            </tr>

                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>


                <div class="col-md-4">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Running Class</div>
                  <div class="panel-body">
                      <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#newclass"> Start new class</button> <hr>
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Class ID</th>
                              <th scope="col">Joining Code</th>
                              <th scope="col">Semester</th>
                              <th scope="col">Schedule</th>
                              <th scope="col" style="width: 30%; text-align: left;">Status</th>
                          </tr>
                        </thead>
                          <tbody>


                              @php $i = 1 @endphp
                              @foreach ($classdata as $classentity)
                              
                              <tr>
                                <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                                <td> {{ $classentity->class_id }}</td>
                                <td> {{ $classentity->joining_code }}</td>
                                <td>{{ $classentity->semester }}</td>
                                <td>{{ $classentity->schedule }}</td>
       <!--                          <td style="text-align: right;">
                                  //<a href="" class="btn btn-sm btn-danger"> See</a>
                                </td> -->
                              </tr>

                              @endforeach


                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>




              <div class="col-md-4">
                  <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Shared Resources Library</div>
                  <div class="panel-body">
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#Acc"> Upload Resource</button> <hr>
                    
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Resource ID</th>
                              <th scope="col">Subject</th>
                              <th scope="col">Topic</th>
                              <th scope="col">Doc Type</th>
                          </tr>
                        </thead>

                          <tbody>
                              <td >CSE101-bd</td>
                              <td >Java Lang</td>
                              <td >Class Dec.</td>
                              <td >PDF</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Read</a></td>
                        </tbody>
                        </th>
       
                      </table>
                  </div>
                </div>
              </div>
            </div>


          </div>

    </div>

  </section>
  <!-- /Section: services -->


@endsection


<!-- Modal -->
<div id="newclass" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New Class</h4>
      </div>
      <div class="modal-body">

        <form action="{{route('addclass')}}" method="post" enctype="multipart/form-data">
         @csrf
        <form>
          <table class="table">

            <tr>
             <td> <label> Class ID</label></td>
             <td> <input type="text" name="class_id"></td>
            </tr>
            <tr>
             <td> <label> Joining Code </label></td>
             <td> <input type="text" name="joining_code"></td>
            </tr>
            <tr>
             <td> <label> Semester</label></td>
             <td> <input type="text" name="semester"></td>
            </tr>

            <tr>
             <td> <label> Schedule</label></td>
             <td> <input type="text" name="schedule"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>

        

        </form>
      </div>
    </div>
  </div>
</div>





<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Daily Bazar Register</h4>
      </div>
      <div class="modal-body">

        <form action="" method="post" enctype="multipart/form-data">
         @csrf
        <form>
          <table class="table">
            <tr>
             <td> <label> Person name</label></td>
             <td> 
              <select name="person">
                <option> Select Person</option>
                <option> Saidur Rahman</option>
                <option> Rifat Hasib</option>
                <option> Alamin</option>
              </select>
             </td>
            </tr>
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="bazar_date"></td>
            </tr>
            <tr>
             <td> <label> Meal Count</label></td>
             <td> <input type="" name="meal_amount"></td>
            </tr>
            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="text" name="tk_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>
         
          
        </form>
      </div>
    </div>
  </div>
</div>

