@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">


            <p class="subtitle" > {{ Session::get('username')}}<br>
             {{ Session::get('userrole')}} <br>
             {{ Session::get('institution')}} 
           </p>
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Profile</a> 
          </div>

          <div class="col-md-10">
            <h4> Student Page </h4>




            <div class="row">


                <div class="col-md-6">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Joined Class</div>
                  <div class="panel-body">
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#joinclass"> Join new Class</button> <hr>

                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col">Class ID</th>
                              <th scope="col">Semester</th>
                              <th scope="col">Schedule</th>
                          </tr>
                        </thead>
                          <tbody>
                              @php $i = 1 @endphp
                              @foreach ($joinedclass as $classentity)
                              
                              <tr>
                                <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                                <td> {{ $classentity->class_id }}</td>
                                <td>{{ $classentity->semester }}</td>
                                <td>{{ $classentity->schedule }}</td>
                                <td style="text-align: right;">
                                  <a href="{{ url('/classdetail/'.$classentity->class_id) }}" class="btn btn-sm btn-danger"> Detail</a>
                                </td>
                              </tr>

                              @endforeach

                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>













          </div>

    </div>

  </section>
  <!-- /Section: services -->


@endsection


<!-- Modal -->
<div id="joinclass" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Join in class</h4>
      </div>
      <div class="modal-body">
        <br>
        
        <form action="{{route('joinclass')}}" method="post" enctype="multipart/form-data">
         @csrf
          <table class="table">
            <input type="hidden" name="memberid" value="{{ Session::get('id')}}">
            <input type="hidden" name="person" value="{{ Session::get('username')}}">

            <tr>
             <td> <label> Enter Class ID</label></td>
             <td> <input type="text" name="joining_code" value="542E$d8d"></td>
            </tr>

            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Join in class"></td>
            </tr>
          </table>
         
          
        </form>
      </div>
    </div>
  </div>
</div>







 <!-- Modal -->
<div id="Acc" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Make Payment</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
        <form action="" method="post" enctype="multipart/form-data">
         @csrf
          <input type="hidden" name="member_id" value="{{ Session::get('id')}}">
          <input type="hidden" name="respose_person" value="{{ Session::get('username')}}">
          <input type="hidden" name="account_type" value="Credit">
          <table class="table">
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="acc_date"></td>
            </tr>
             <tr>
             <td> <label> Accounts name</label></td>
             <td> 
                  <select name="account_name">
                    <option> Select Name</option>
                    <option> Member Subs. Fee</option>
                    <option> Service Charge</option>
                  </select>
             </td>
           </tr>
            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="" name="payment_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>

