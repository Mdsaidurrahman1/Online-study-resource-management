@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-5 col-lg-offset-2 loginform" >

          @if ($errors->any())
              <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                      @endforeach
                  </ul>
              </div>
          @endif




            <h2> Member Register form</h2>  
                  @if (Session::has('message'))
                     <div class="alert alert-warning">{{ Session::get('message') }}</div>
                  @endif
              <form action="{{ route('registerpost') }}" method="POST" >
                @csrf
                <input type="hidden" name="" value="">


                <input type="hidden" class="form-control" id="exampleInputEmail1" name="role" value="Member" aria-describedby="emailHelp" >

                <div class="form-group">
                  <label for="exampleInputEmail1">Frist Name</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="first_name" aria-describedby="emailHelp" placeholder="Enter first name">
                </div>

                 <div class="form-group">
                  <label for="exampleInputEmail1">Last Name </label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="last_name" aria-describedby="emailHelp" placeholder="Enter last name">
                </div>



                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="username" aria-describedby="emailHelp" placeholder="Enter user name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Date of Birth</label>
                  <input type="date" class="form-control" id="exampleInputEmail1" name="date_of_birth" aria-describedby="emailHelp" placeholder="">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Institution name</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="institution" aria-describedby="emailHelp" placeholder="Enter institution name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">User Role</label>
                  <select class="form-control" name="user_role" >
                    <option value=""> Select Role</option>
                    <option value="Student"> Student</option>
                    <option value="Professor"> Professor</option>
                    <option value="Advisor"> Advisor</option>
                  </select>
                  <input type="text" id="exampleInputEmail1"  aria-describedby="emailHelp" placeholder="Enter user name">
                </div>









                <div class="form-group">
                  <label for="exampleInputEmail1">Contact No</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="contact_no" aria-describedby="emailHelp" placeholder="Enter contact No">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Email</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" class="form-control" id="exampleInputEmail1" name="password" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

               <br><input type="submit" class="btn btn-info"value="Register">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


@endsection


 