<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Miliscript</title>

  <!-- css -->
  <link href="{{ URL::asset('resources/assets/css/bootstrap.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ URL::asset('resources/assets/font-awesome/css/font-awesome.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ URL::asset('resources/assets/css/nivo-lightbox.css') }}" rel="stylesheet" />
  <link href="{{ URL::asset('resources/assets/css/nivo-lightbox-theme/default/default.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ URL::asset('resources/assets/css/owl.carousel.css') }}" rel="stylesheet" media="screen" />
  <link href="{{ URL::asset('resources/assets/css/owl.theme.css') }}" rel="stylesheet" media="screen" />
  <link href="{{ URL::asset('resources/assets/css/flexslider.css') }}" rel="stylesheet" />
  <link href="{{ URL::asset('resources/assets/css/animate.css') }}" rel="stylesheet" />
  <link href="{{ URL::asset('resources/assets/css/style.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('resources/assets/color/default.css') }}" rel="stylesheet">
          
  <script src="{{ URL::asset('resources/assets/js/vue.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery-3.3.1.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.min.js') }}"></script>
  <link href="{{ URL::asset('resources/assets/css/mystyle.css') }}" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


  <!-- Navigation -->
  <div id="navigation" style="background-image:url({{ URL::asset('resources/assets/img/back5.png') }})">
    <nav class="navbar navbar-custom" role="navigation">
      <div class="">
        <div class="row" >
          <div class="col-md-2">
            <div class="site-logo">
              <a href="{{ route('root') }}" class="brand"><img src="{{ URL::asset('resources/assets/img/logo.png') }}" class="img-responsive" alt="miliscript"></a>
            </div>
          </div>


          <div class="col-md-10">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu"><i class="fa fa-bars"></i></button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="menu">
              <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="{{ route('root') }}">Home</a></li>
              <!--   <li><a href="{{ route('about') }}">About Us</a></li> -->
                @if (Session::has('username'))
                     <li><a href="{{ route('signout') }}">Sign Out</a></li>
                @else
                <li><a href="{{ route('userlogin') }}">Login</a></li>
                <li><a href="{{ route('userregister') }}">Register</a></li>
                @endif
                
               <!--  <li><a href="{{ url('/register') }}">Register</a></li>     -->
              </ul>
            </div>
            <!-- /.Navbar-collapse -->

          </div>
        </div>
      </div>
      <!-- /.container -->
    </nav>
  </div>
  <!-- /Navigation -->


 <section id="intro" class="home-slide text-light">


   

  @yield('content')



  <footer>
    <div class="container">
      <div class="row footerset">

       <div class="col-md-6">
            <p><span style="font-weight:bold; font-size: 40px; color: #dabdbd;"><i>ECampus</i></span>
        </div>

        <div class="col-md-6">
          <div class="text-center">
            All rights reserved by : <a href="https://miliscript.com/">Miliscript System</a>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <link href="{{ URL::asset('resources/assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">

  <script src="{{ URL::asset('resources/assets/js/bootstrap.min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.sticky.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.flexslider-min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.easing.min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.scrollTo.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/jquery.appear.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/stellar.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/wow.min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/owl.carousel.min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/nivo-lightbox.min.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/js/custom.js') }}"></script>
  <script src="{{ URL::asset('resources/assets/contactform/contactform.js') }}"></script>




</body>

</html>
