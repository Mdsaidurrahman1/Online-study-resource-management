@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Account Detail</a> 
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Make Payment</a> 
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Meal Request</a> 
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Profile</a> 
          </div>

          <div class="col-md-10">
            <p class="subtitle" > {{$user->username}}  _ {{$user->role}}  _ Dashboard </p> <hr>

            <p class="subtitle" > </p> <hr>






          </div>

    </div>

  </section>
  <!-- /Section: services -->


@endsection


 