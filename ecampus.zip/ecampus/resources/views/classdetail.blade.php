@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">


            <p class="subtitle" > {{ Session::get('username')}}<br>
             {{ Session::get('userrole')}} <br>
             {{ Session::get('institution')}} 
           </p>
            <a href="{{ route('memberdashboard') }}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Deshboard</a> 
          </div>

          <div class="col-md-10">
            <h4> {{ $resouce[0]->class_id}} Class Detail</h4>




            <div class="row">


                <div class="col-md-6">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading"> All Class Resource</div>
                  <div class="panel-body">
                                  
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col">Semester</th>
                              <th scope="col">Schedule</th>
                              <th scope="col">Resource Type</th>
                              <th scope="col">Message</th>
                          </tr>
                        </thead>
                          <tbody>
                              @php $i = 1 @endphp
                              @foreach ($resouce as $res)
                              
                              <tr>
                                <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                                <td>{{ $res->subject }}</td>
                                <td>{{ $res->date }}</td>
                                <td>{{ $res->type }}</td>
                                <td>{{ $res->message }}</td>
                                <td style="text-align: right;">
                                  <a href="http://localhost/ecampus/{{ $res->link}}" class="btn btn-sm btn-danger"> View Resouce</a>
                                                 
                                </td>
                              </tr>

                              @endforeach


          

                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>




              <div class="col-md-5">
                  <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">All Assignment</div>
                  <div class="panel-body"><!-- 
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#Acc"> Make Payment</button> <hr>
             -->        
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col" style="width: 20%">Publish date</th>
                              <th scope="col">Subject</th>
                              <th scope="col">Message</th>
                              <th scope="col">Message</th>
                          </tr>
                        </thead>
                          <tbody>
                              @php $i = 1 @endphp
                              @foreach ($assignment as $assginmentnotice)
                              
                              <tr>
                                <td scope="row">  @php echo  $i++ ;  @endphp  </td>
                                <td>{{ $assginmentnotice->posting_date }}</td>
                                <td>{{ $assginmentnotice->subject }}</td>
                                <td>{{ $assginmentnotice->message }}</td>
                                <td>
                                  <a href="" class="btn btn-sm btn-danger"> Like </a>
                                </td>
                              </tr>

                              @endforeach


          

                          </tbody>
       
                      </table>
                </div>
              </div>
            </div>









          </div>

    </div>

  </section>
  <!-- /Section: services -->


@endsection


