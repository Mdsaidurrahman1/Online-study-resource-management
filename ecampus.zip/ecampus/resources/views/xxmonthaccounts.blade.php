@extends('template')

@section('content')

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
            <a href="{{route('accounts')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Account Detail</a> 
            <a href="{{route('mealmanage')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Meal Management</a> 
            <a href="{{route('bazarmanage')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Bazar Management</a>
            <a href="{{route('monthendacc')}}" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Manthly Acc</a>        

          </div>

          <div class="col-md-10">
            <div class="row ">
              <div class="col-md-6">
              <p class="subtitle" > Account Information</p>
              <table class="table">
                 <tr>
                 <td> <label> Start Date</label></td>
                 <td> 
                    <input type="date" name="accStartDate" id="accStartDate">
                 </td>

                 <td> <label> End Date</label></td>
                 <td> 
                    <input type="date" name="accEndDate" id="accEndDate">
                 </td>
              </table>
              <hr>
            </div>
          </div>

            <div class="row">

            <div class="col-md-12">
              <p class="subtitle" >Monthly Accounts Details</p>
              <div class="row">
                <div class="col-md-6">
                      <div class="panel panel-primary">
                        <!-- Default panel contents -->
                        <div class="panel-heading">Debit Accounts</div>
                        <div class="panel-body">
                            <table class="table" id="debitTable">
                              <thead>
                                <tr>
                                  <th>Sl</th><th>Date</th><th>Account Name</th><th>Amount</th>
                                </tr>
                              </thead>
                                <tbody>
                                </tbody>
             
                            </table>
                        </div>
                      </div>
                </div>
                <div class="col-md-5">
                      <div class="panel panel-primary">
                        <!-- Default panel contents -->
                        <div class="panel-heading">Credit Accounts</div>
                        <div class="panel-body">
                            <table class="table" id="creditTable">
                              <thead>
                                <tr>
                                  <th>Sl</th><th>Date</th><th>Account Name</th><th>Amount</th>
                                </tr>
                              </thead>
                                <tbody>

                                </tbody>
             
                            </table>
                        </div>
                      </div>
                </div>
              </div>
            </div>

          </div>
          </div>

          </div>

    </div>

  </section>
  <!-- /Section: services -->


<script type="text/javascript">


  $( "#addtbn" ).hide() ;
  $('#accEndDate').hide() ;
  $( "#account_type" ).hide();

$(document).ready(function(){


     $( "#accStartDate" ).change(function() {
        $('#accEndDate').show() ;
     });

    var totalDebitAmount=0;
     var totalCreditAmount=0;



     $( "#accEndDate" ).change(function() {
        var startDate = $("#accStartDate").val();
        var endDate = $("#accEndDate").val();
        var acctype = $( "#account_type" ).val();

         $.ajax({
          url:"{{url('/getaccounts') }}",
          method: 'GET',
          data: {'startDate':startDate, 'endDate':endDate},
            
          success: function(data)
          {
          totalDebitAmount=0;
          totalCreditAmount=0;
           $('#creditTable').html('');
            
            $('#creditTable').append('<thead><tr><th scope="col">#</th><th scope="col">Date</th><th style="width:30%" scope="col">Account Name</th><th style="text-align:right">Tk. Amount</th></tr></thead><tbody>');

            $.each(data, function( key, value ) 
            {

              if(value.account_type == 'Credit')
              {
                totalDebitAmount+=value.payment_amount;
                  $('#creditTable').append('<tr>            <td scope="row">'+ ++key +'</td>            <td> '+ value.acc_date +'</td>            <td> '+ value.account_name +'</td>            <td style="text-align:right">'+ value.payment_amount +'</td>                            </tr>');
              }
            });
             $('#creditTable').append('<thead><tr><th scope="col"></th><th scope="col"></th><th style="width:30%" scope="col">Total Monthly Credit</th><th style="text-align:right">'+totalDebitAmount+'</th></tr></thead><tbody>');
            $('#creditTable').append('</tbody>');

      // dddddddd ---------------------------------------------------------------
            $('#debitTable').html('');
            
            $('#debitTable').append('<thead><tr><th scope="col">#</th><th scope="col">Date</th><th style="width:30%" scope="col">Account Name</th><th style="text-align:right">Tk. Amount</th></tr></thead><tbody>');

            $.each(data, function( key, value ) 
            {
              
              if(value.account_type == 'Debit')
              {
                totalCreditAmount+=value.payment_amount;
                $('#debitTable').append('<tr>            <td scope="row">'+ ++key +'</td>            <td> '+ value.acc_date +'</td>            <td> '+ value.account_name +'</td>            <td style="text-align:right">'+ value.payment_amount +'</td>                            </tr>');
                 }           
            });
            $('#debitTable').append('<thead><tr><th scope="col"></th><th scope="col"></th><th style="width:30%" scope="col">Total Monthly Debit</th><th style="text-align:right">'+totalCreditAmount+'</th></tr></thead><tbody>');
            $('#debitTable').append('</tbody>');
          },
        });


  });

});
</script>
















@endsection


<!-- Modal -->
<div id="myModalaccount" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Account Entry</h4>
      </div>
      <div class="modal-body">

        <form action="{{route('accpost')}}" method="post" enctype="multipart/form-data">
         @csrf
        <form>
          <table class="table">
            <tr>
             <td> <label> Person name</label></td>
             <td> 
              <select name="account_type">
                <option> Select Type</option>
                <option> Debit</option>
                <option> Credit</option>
              </select>
             </td>
            </tr>
            <tr>
             <td> <label> Name</label></td>
             <td> <input type="text" name="account_name"></td>
            </tr>
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="acc_date"></td>
            </tr>
            <tr>
             <td> <label> Responsible Person </label></td>
             <td> <input type="text" name="respose_person"></td>
            </tr>

            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="text" name="payment_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>

        </form>
      </div>
    </div>
  </div>
</div>





<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Daily Bazar Register</h4>
      </div>
      <div class="modal-body">

        <form action="{{route('bazarpost')}}" method="post" enctype="multipart/form-data">
         @csrf
        <form>
          <table class="table">
            <tr>
             <td> <label> Person name</label></td>
             <td> 
              <select name="person">
                <option> Select Person</option>
                <option> Saidur Rahman</option>
                <option> Rifat Hasib</option>
                <option> Alamin</option>
              </select>
             </td>
            </tr>
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="bazar_date"></td>
            </tr>
            <tr>
             <td> <label> Meal Count</label></td>
             <td> <input type="" name="meal_amount"></td>
            </tr>
            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="text" name="tk_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>
         
          
        </form>
      </div>
    </div>
  </div>
</div>

