-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2019 at 07:11 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecampusbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(10) UNSIGNED NOT NULL,
  `owner` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posting_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `owner`, `class_id`, `subject`, `message`, `posting_date`, `created_at`, `updated_at`) VALUES
(1, '12', 'C++', 'Class Test', 'sdf ad kasldf asdf asdf jsdkflas dfas dkflasdf aksldf sadfl asdjfklsd fsadf asjdkflasd fas dfjksaldf sahdjklfasdf sadjkflsadf', '2019-08-30 10:44:16', '2019-08-29 22:44:16', '2019-08-29 22:44:16'),
(2, '12', 'eeeeee', 'eeeeeeee', '43234werw bdsf ffffffffffffffffffffffffffffffffffeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', '2019-08-30 10:50:05', '2019-08-29 22:50:05', '2019-08-29 22:50:05');

-- --------------------------------------------------------

--
-- Table structure for table `classbs`
--

CREATE TABLE `classbs` (
  `id` int(10) UNSIGNED NOT NULL,
  `class_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joining_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assign_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classbs`
--

INSERT INTO `classbs` (`id`, `class_id`, `joining_code`, `owner_name`, `assign_by`, `semester`, `schedule`, `status`, `created_at`, `updated_at`) VALUES
(5, 'CSE 150 Eve A', 'jdf789)775', NULL, NULL, 'Spring', 'Friday 5-7 pm', NULL, '2019-08-03 03:43:08', '2019-08-03 03:43:08'),
(6, 'CSE 150 Eve A', 'dddre@#', NULL, NULL, 'Summer', 'Sunday', NULL, '2019-08-03 03:47:30', '2019-08-03 03:47:30'),
(7, 'sdfgsdfgdsfg', 'eeee234324', NULL, NULL, 'sdfs', 'rtre', NULL, '2019-08-03 03:48:23', '2019-08-03 03:48:23'),
(8, 'eeeeee', 'dddddd', NULL, NULL, 'ffffff', '4444', NULL, '2019-08-03 03:50:53', '2019-08-03 03:50:53'),
(9, 'asdfhgjkl', 'asdf', NULL, NULL, 'Spring', 'sunday', NULL, '2019-08-29 13:53:41', '2019-08-29 13:53:41'),
(10, 'C++', 'asdf123', NULL, NULL, 'Summer', 'Sunday', NULL, '2019-08-29 14:02:54', '2019-08-29 14:02:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_11_06_181103_service', 1),
(2, '2018_11_09_164856_create_works_table', 2),
(3, '2018_11_10_050147_create_messages_table', 3),
(4, '2018_11_24_062936_create_linkrefferences_table', 4),
(5, '2018_11_24_072507_create_super_catetories_table', 5),
(6, '2018_11_24_073148_create_catetories_table', 6),
(7, '2018_11_24_073847_create_catetories_table', 7),
(8, '2018_11_24_074138_create_sub_catetories_table', 8),
(9, '2018_11_28_033253_create_object_cats_table', 9),
(10, '2018_12_06_171939_create_objects_table', 10),
(11, '2018_12_06_172451_create_properties_table', 11),
(12, '2018_12_06_173302_create_actions_table', 12),
(13, '2019_01_03_175915_create_properties_table', 13),
(14, '2019_01_11_165101_create_modules_table', 14),
(15, '2019_01_17_061700_create_object_references_table', 15),
(16, '2019_01_17_165025_create_action_libs_table', 16),
(17, '2019_01_19_155715_create_link_details_table', 17),
(18, '2019_03_10_102851_create_bazers_table', 18),
(19, '2019_03_11_070813_create_dailymeals_table', 19),
(20, '2019_03_11_081033_create_accounts_table', 20),
(21, '2019_08_03_065428_create_assignments_table', 21),
(22, '2019_08_03_065753_create_classes_table', 22),
(23, '2019_08_03_070037_create_resources_table', 23),
(24, '2019_08_03_082221_create_student_classes_table', 24);

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(10) UNSIGNED NOT NULL,
  `class_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`id`, `class_id`, `subject`, `date`, `type`, `message`, `link`, `created_at`, `updated_at`) VALUES
(1, 'CSE 150 Eve A', 'werwer', '2019-08-30 00:47:47', 'sdfg', 'wewr', 'C:\\xampp\\tmp\\php3EFE.tmp', '2019-08-29 12:47:47', '2019-08-29 12:47:47'),
(2, 'sdfgsdfgdsfg', 'rrrrrrrr', '2019-08-30 00:51:53', '444', 'erter', 'C:\\xampp\\tmp\\phpFED4.tmp', '2019-08-29 12:51:52', '2019-08-29 12:51:52'),
(3, 'CSE 150 Eve A', 'werwer', '2019-08-30 01:08:53', 'wer', 'sf', 'uploadedloc/safe_image.png', '2019-08-29 13:08:53', '2019-08-29 13:08:53'),
(4, 'CSE 150 Eve A', 'asdfa', '2019-08-30 01:11:03', 'ewrwe', 'sdf', 'uploadedloc/Associate Software Engineer.docx', '2019-08-29 13:11:03', '2019-08-29 13:11:03'),
(5, '6', 'ertert', '2019-08-30 01:43:44', 'ert', 'twert', 'uploadedloc/Resume of Md. Saidur Rahman.pdf', '2019-08-29 13:43:44', '2019-08-29 13:43:44'),
(6, 'asdfhgjkl', 'Java', '2019-08-30 01:54:16', 'doc', 'cT', 'uploadedloc/Assignment no 2.docx', '2019-08-29 13:54:16', '2019-08-29 13:54:16'),
(7, 'C++', 'DataType', '2019-08-30 02:03:26', 'pdf', 'Read', 'uploadedloc/bracbank48a.jpg', '2019-08-29 14:03:26', '2019-08-29 14:03:26');

-- --------------------------------------------------------

--
-- Table structure for table `student_classes`
--

CREATE TABLE `student_classes` (
  `id` int(10) UNSIGNED NOT NULL,
  `class_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `semester` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Student_id` int(11) DEFAULT NULL,
  `class_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_classes`
--

INSERT INTO `student_classes` (`id`, `class_id`, `semester`, `schedule`, `Student_id`, `class_name`, `student_name`, `created_at`, `updated_at`) VALUES
(10, 'CSE 150 Eve A', NULL, NULL, 11, NULL, NULL, '2019-08-03 03:45:42', '2019-08-03 03:45:42'),
(15, 'eeeeee', 'ffffff', '4444', 11, NULL, NULL, '2019-08-03 03:51:05', '2019-08-03 03:51:05'),
(16, 'eeeeee', 'ffffff', '4444', 11, NULL, NULL, '2019-08-03 03:53:17', '2019-08-03 03:53:17'),
(17, 'sdfgsdfgdsfg', 'sdfs', 'rtre', 11, NULL, NULL, '2019-08-03 03:53:29', '2019-08-03 03:53:29'),
(18, 'CSE 150 Eve A', 'Summer', 'Sunday', 12, NULL, NULL, '2019-08-29 13:13:21', '2019-08-29 13:13:21'),
(19, 'asdfhgjkl', 'Spring', 'sunday', 11, NULL, NULL, '2019-08-29 13:54:40', '2019-08-29 13:54:40'),
(20, 'C++', 'Summer', 'Sunday', 11, NULL, NULL, '2019-08-29 14:04:17', '2019-08-29 14:04:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institution` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `date_of_join` date DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `user_role`, `institution`, `date_of_birth`, `date_of_join`, `contact_no`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(10, NULL, NULL, 'alamin', NULL, NULL, '2000-01-11', '2019-03-22', 123545454, 'Member', 'alamin@a.com', NULL, 'asdf', NULL, '2019-03-22 05:00:45', '2019-03-22 05:00:45'),
(11, 'saidur', 'rahman', 'saidur', 'Student', 'Green uni', '2019-08-01', NULL, 101244524, 'Member', 'as@df.com', NULL, '1234', NULL, '2019-08-01 11:30:06', '2019-08-01 11:30:06'),
(12, 'rahman', 'mia', 'professor', 'Professor', 'Green uni', '2019-08-01', NULL, 23423423, 'Member', 'rahman@r.com', NULL, '1234', NULL, '2019-08-01 11:35:55', '2019-08-01 11:35:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classbs`
--
ALTER TABLE `classbs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_classes`
--
ALTER TABLE `student_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classbs`
--
ALTER TABLE `classbs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `student_classes`
--
ALTER TABLE `student_classes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
