<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentClass extends Model
{
        protected $fillable = ['class_id', 'Student_id','semester','schedule', 'class_name', 'student_name'];
}
