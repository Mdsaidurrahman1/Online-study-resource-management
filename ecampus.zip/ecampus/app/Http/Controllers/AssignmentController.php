<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Classb;
use App\StudentClass;
use App\Assignment;
use Session;
use Redirect;
use App\Lib\Repository;
use DB;

class AssignmentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $_userModel;
    public function __construct(Assignment $eclass)
    {
        $this->_userModel = new Repository($eclass);
    }


    public function AssignmentPost(Request $request)
    {

        $user = User::all();
        $classdata= (new Repository(new Classb))->getAll() ; 
        $postedassignment= $this->_userModel->getAll() ; 
        return view('assignment')->with('user',$user)->with('classdata',$classdata)->with('assignment',$postedassignment);
    }






    public function Assignmentpublish(Request $request)
    {

        $this->validate($request, [
            'class_id' => 'required',
            'subject' => 'required',
            'message' =>'required'
        ]);

       $request->merge(['owner' => session('id')]);

        $this->_userModel->store($request->only($this->_userModel->getModel()->fillable));
            Session::flash('Successmessage', "Register successfull! please login");
            return Redirect::route('addassignment');

      //   $user = User::all();
      //   $classdata= (new Repository(new Classb))->getAll() ; 
      //   return view('assignment')->with('user',$user)->with('classdata',$classdata);
    }








    public function ClassPost(Request $request)
    {
    	 $this->validate($request, [
                'class_id' => 'required',
                'joining_code' => 'required',
                'semester' =>'required',
                'schedule'=>'required'
        ]);

        $this->_userModel->store($request->only($this->_userModel->getModel()->fillable));
            Session::flash('Successmessage', "Register successfull! please login");
            return Redirect::route('admin');
    }




    public function JoinClass(Request $request)
    {

        $this->validate($request, [
                'joining_code' => 'required'
        ]);

        $joiningkey = $request->joining_code;
        $class = ((new Repository(new Classb))->getByKyeId('joining_code',$joiningkey));

        $class_id = $class->class_id;
        $Student_id = Session::get('id'); 


        //$request->merge(['class_id' => $class_id]);
        //$request->merge(['Student_id' =>  $Student_id]);

        DB::insert('insert into student_classes (class_id, Student_id) values (?, ?)', [$class_id, $Student_id]);
        


        return redirectback();


    }








    // public function admin(Request $request)
    // {
    //     $user = User::all();
    //     $accdata= (new Repository(new Account))->getAll() ; 
    //     $bazardata = (new Repository(new Bazer))->getAll() ; 
    //     $mealdata = (new Repository(new Dailymeal))->getAll() ; 
    //     $adminuser  =  $this->_userModel->getById($request->id);
    //     return view('admin')->with('user',$user)->with('adminuser',$adminuser)->with('bazar',$bazardata )
    //     ->with('mealdata',$mealdata)
    //     ->with('accdata',$accdata);
    // }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
  


}
