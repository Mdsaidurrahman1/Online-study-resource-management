<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Classb;
use Session;
use Redirect;
use App\Lib\Repository;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $_userModel;
    public function __construct(User $user)
    {
        $this->_userModel = new Repository($user);
    }



    public function admin(Request $request)
    {
        $user = User::all();
        $classdata= (new Repository(new Classb))->getAll() ; 
        return view('admin')->with('user',$user)->with('classdata',$classdata);
    }


    // public function admin(Request $request)
    // {
    //     $user = User::all();
    //     $accdata= (new Repository(new Account))->getAll() ; 
    //     $bazardata = (new Repository(new Bazer))->getAll() ; 
    //     $mealdata = (new Repository(new Dailymeal))->getAll() ; 
    //     $adminuser  =  $this->_userModel->getById($request->id);
    //     return view('admin')->with('user',$user)->with('adminuser',$adminuser)->with('bazar',$bazardata )
    //     ->with('mealdata',$mealdata)
    //     ->with('accdata',$accdata);
    // }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
  


}
