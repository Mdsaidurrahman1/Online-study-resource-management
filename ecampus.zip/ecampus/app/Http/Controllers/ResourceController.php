<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Classb;
use App\StudentClass;
use App\Resource;
use Session;
use Redirect;
use App\Lib\Repository;
use DB;

class ResourceController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $_userModel;
    public function __construct(Resource $eclass)
    {
        $this->_userModel = new Repository($eclass);
    }


    public function Resource(Request $request)
    {

        $user = User::all();
        $classdata= (new Repository(new Classb))->getAll() ; 
        $resourcedata= $this->_userModel->getAll() ; 
        return view('resource')->with('user',$user)->with('classdata',$classdata)->with('resource',$resourcedata);
    }



    public function ResourcePost(Request $request)
    {


         $this->validate($request, [
                'class_id' => 'required',
                'subject' => 'required',
                'res' =>'required'
        ]);

      $res = $request->res;
      $resTitle = $res->getClientOriginalName();
      $fileExtention = $res->getClientOriginalExtension();
      if($fileExtention!='jpg' and $fileExtention!='png'and $fileExtention!='pdf'and $fileExtention!='docx')
      {
        Session::flash('message', "Only mp4 or 3gp or avi are allow to upload");
          return Redirect::back();
      }

      //Move Uploaded File
      $destinationPath = 'uploadedloc';
      $res->move($destinationPath,$res->getClientOriginalName());
      $fileUrl = $destinationPath.'/'.$resTitle;

      $request->merge(['link' => $fileUrl]);


        $this->_userModel->store($request->only($this->_userModel->getModel()->fillable));
            Session::flash('Successmessage', "Register successfull! please login");
            return Redirect::route('addresource');
    }



  


}
