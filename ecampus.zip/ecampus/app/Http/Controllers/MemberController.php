<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use Redirect;
use Validator;
use App\User;
use App\StudentClass;
use App\Classb;
use App\Lib\Repository;


class MemberController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $_userModel;
    public function __construct(User $user)
    {
        $this->_userModel = new Repository($user);
    }



    public function dashboard(Request $request)
    {
        $id = session('id');
        $sclass = ((new Repository(new StudentClass))->getByKyeId('Student_id',$id));
        return view('Dashboard')->with('joinedclass',$sclass);
    }



    public function profile(Request $request)
    {
        return view('profile');
    }



  

}
