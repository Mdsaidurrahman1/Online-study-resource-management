<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classb extends Model
{
    protected $fillable = ['class_id','joining_code','owner_name','assign_by','semester','schedule'];
}


