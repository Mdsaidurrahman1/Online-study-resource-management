<?php

namespace App\Lib;

use Illuminate\Database\Eloquent\Model;


class Repository implements RepositoryInterface
{

	protected $Model;
    public function __construct(Model $model)
    {
        $this->Model = $model;
    }

    public function getAll()
    {
    	return $this->Model->all();
    }


    public function getByKyeId($key,$id)
    {
        return $this->Model->where($key, '=', $id)->get();
    }

   	public function getById($id)
   	{
   		return $this->Model->find($id);
   	}


    public function store(array $model)
    {
    	return $this->Model->create($model);
    }

    public function update(array $model,$id)
    {
    	$keymodel = $this->Model->find($id);
    	$keymodel->update($model);
    	return true;
    }

    public function delete($id)
    {
    	$model =  $this->Model->find($id);
    	$model->delete();
    	return true;
    }
    
    public function getModel()
    {
    	return $this->Model;
    }

}