<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resource extends Model
{
        protected $fillable = ['class_id','subject', 'date', 'type', 'message', 'link'];
}

