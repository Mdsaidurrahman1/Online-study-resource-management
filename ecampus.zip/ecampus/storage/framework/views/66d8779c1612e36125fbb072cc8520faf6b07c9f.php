<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">

       <!--        <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a>  -->
       <!--        <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Web Refference</a>  -->
             
          </div>

          <div class="col-md-10">
            <p class="subtitle" > <u> <?php echo e($loginstatus[0]->username); ?> </u> Dashboard </p> <hr>

            <p class="subtitle" > </p> <hr>






          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>