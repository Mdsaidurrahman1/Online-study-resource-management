<?php $__env->startSection('content'); ?>
<div class="contentsection">
<h1> Content Management</h1>
<button class="btn btn-success">Create</button> <hr>

<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
      <th scope="col" style="width: 30%; text-align: right;">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
      <td style="width: 30%; text-align: right;">
        <a href="" class="btn btn-sm btn-info"> Detail </a>
        <a href="" class="btn btn-sm btn-warning"> Delete </a>
        <a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
      <td style="width: 30%; text-align: right;">
        <a href="" class="btn btn-sm btn-info"> Detail </a>
        <a href="" class="btn btn-sm btn-warning"> Delete </a>
        <a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
      <td style="width: 30%; text-align: right;"">
        <a href="" class="btn btn-sm btn-info"> Detail </a>
        <a href="" class="btn btn-sm btn-warning"> Delete </a>
        <a href="" class="btn btn-sm btn-info"> Update </a>
      </td>
    </tr>
  </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>