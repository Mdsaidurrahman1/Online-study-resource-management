<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">

            <p class="subtitle" > <?php echo e(Session::get('username')); ?><br>
             <?php echo e(Session::get('userrole')); ?> <br>
             <?php echo e(Session::get('institution')); ?> 
           </p>
            <a href="<?php echo e(route('admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Add New Class</a> 
            <a href="<?php echo e(route('addresource')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Upload Resource</a> 
            <a href="<?php echo e(route('addassignment')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Set Assignment</a>
          </div>

          <div class="col-md-10">

            <h4> Professor Panel <h4>



           <div class="row">



                <div class="col-md-7">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">All Resource</div>
                  <div class="panel-body">
                      <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#newclass"> + Resource</button> <hr>
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col">Class ID</th>
                              <th scope="col">Subject </th>
                              <th scope="col">Type</th>
                              <th scope="col">Message</th>
                          </tr>
                        </thead>
                          <tbody>


                              <?php $i = 1 ?>
                              <?php $__currentLoopData = $resource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourcedate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                              <tr>
                                <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                <td> <?php echo e($resourcedate->class_id); ?></td>
                                <td> <?php echo e($resourcedate->subject); ?></td>
                                <td><?php echo e($resourcedate->type); ?></td>
                                <td><?php echo e($resourcedate->message); ?></td>
                                <td style="text-align: right;">
                                  <a href="<?php echo e($resourcedate->link); ?>" class="btn btn-sm btn-danger"> See</a>
                                </td>
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>



              </div>



            </div>


          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


<!-- Modal -->
<div id="newclass" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New Class</h4>
      </div>
      <div class="modal-body">

        <form action="<?php echo e(route('addnewresource')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
        <form>
          <table class="table">

            <tr>
             <td> <label> Class ID</label></td>
             <td> 

              <select name="class_id">
                <option value="" >Select class</option>
                <?php $i = 1 ?>
                <?php $__currentLoopData = $classdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($classentity->class_id); ?>"><?php echo e($classentity->class_id); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]

              </select>
            </tr>
            <tr>
             <td> <label> Subject </label></td>
             <td> <input type="text" name="subject"></td>
            </tr>

            <tr>
             <td> <label> Type</label></td>
             <td> <input type="type" name="type"></td>
            </tr>
            <tr>
             <td> <label> Message</label></td>
             <td> <input type="text" name="message"></td>
            </tr>
            <tr>
             <td> <label> File</label></td>
             <td> <input type="file" name="res"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>



        </form>
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>