<?php $__env->startSection('content'); ?>

   <!-- Section: contact -->
  <section id="contact" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/contact.jpg')); ?>) "class="contact">


    
    <div class="container">
      <br>

      <div class="row marginbot-80">
        <div class="col-md-3"> </div>
        <div class="col-md-3 formloc">
          <h3><span style="color: #fff;"> Leave us a message</span></h3>
          <div id="errormessage"></div>
          <form action="<?php echo e(route('usermessage')); ?>" method="post" role="form" class="">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <input type="text" name="sendername" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="sendercontact" id="email" placeholder="Your contact no" data-rule="email" data-msg="Please enter a valid email" />
              <div class="validation"></div>
            </div>

            <div class="form-group">
              <input type="email" class="form-control" name="senderemail" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
              <div class="validation"></div>
            </div>


            <div class="form-group">
              <input type="text" class="form-control" name="messagesubject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="3" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
              <div class="validation"></div>
            </div>

            <div class="text-center"><button type="submit" class="btn btn-skin  btn-block">Send Message</button></div>
          </form>

        </div>

        <div class="col-md-6 addressloc">
            <?php if(Session::has('SuccessMessage')): ?>
                  <div class="alert alert-danger" role="alert">
                    ----------------------------------------<br>
                    <strong>Attention!</strong> <?php echo e(Session::get('SuccessMessage')); ?>  
                    <br>
                    ----------------------------------------  
                  </div>
             <?php endif; ?>
        <h1> Contact Us</h1>
          <span style="color: #690b0b; font-size: 18px;">
                      Contact No : <span style="font-weight:bold;">01723-537366, 01816-066666, 253-5222142</span><br>
          Email : <span style="font-weight:bold;">momin.hamimenterprise8@gmail.com</span><br>
          </span>


           <span style="color: #690b0b; font-size: 18px;">
            <br><h1>Find us in here</h1>
            <p><span style="font-weight:bold;">Washing Plant-Hamim Enterprise</span> <br>
              74, Monipur, Mipur, Dhaka<br></p>
          </span>



          <br>

        </div>
      </div>


    </div>
  </section>
  <!-- /Section: contact -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>