<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p>Admin Dashboard</p>
          </div>
        </div>
      </div>
    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-3 menu">
              <a href="<?php echo e(route('admin_service')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-home"> </i> Service</a> 
              <a href="<?php echo e(route('admin_work')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Work</a> 
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> News</a> 
              <a href="<?php echo e(route('admin_content')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Content Management</a>
             
             
          </div>

          <div class="col-md-8">
          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>