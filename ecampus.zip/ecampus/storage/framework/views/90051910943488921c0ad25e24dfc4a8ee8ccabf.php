<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Property Management</p>
          </div>

          <div class="col-md-10 tail">
              <a href="<?php echo e(route('settingsmodule')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Setup Module</a> 
              <a href="<?php echo e(route('linklib')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Web Refference</a> 
              <a href="<?php echo e(route('object')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Object Library</a> 
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 sideform">
            <p class="subtitle" > Property Entity Management</p>

            <?php if(Session::has('foundmsg')): ?>
            <div class="alert alert-danger" role="alert">
              <strong>Attention!</strong> <?php echo e(Session::get('foundmsg')); ?>    
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('propertyIn')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">New Property</label>
                  <input type="text" class="form-control" id="propertyName" name="PropertyName" aria-describedby="emailHelp" placeholder="Enter object cat desc">
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Super Category</label>
                  <select class="form-control" id="supercategory" name="SupCatId">
                    <option class="Education">Select Category</option>
                      <?php $__currentLoopData = $supcatpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->SuperCateName); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Category</label>
                  <select class="form-control" id="category" name="CatId">
                    <option class="Education">Select Category</option>
                  </select>
                </div>


                <div class="form-group">
                  <label for="exampleInputEmail1">Sub Category</label>
                  <select class="form-control" id="subcategory" name="SubCatId">
                    <option class="Education">Select Category</option>
                  </select>
                </div>

<!--                 <div class="form-group">
                  <label for="exampleInputEmail1">Object Category</label>
                  <select class="form-control" id="objcategory" name="ObjCatId">
                    <option class="Education">Select Category</option>
                  </select>
                </div>
 -->


                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-10">

           <div class="contentsection">
    
                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>

             <p class="subtitle" > All Property Info</p>

              <table class="table table-sm table-hover"  id="categorytable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Object Cat Name</th>
                    <th scope="col">Super Cate ID</th>
                    <th scope="col">Category ID</th>
                    <th scope="col">Sub Cat ID</th>
                    <th scope="col">Object Cat ID</th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>

                   <?php $i = 1 ?>
                  <?php $__currentLoopData = $pptPack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppPack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($ppPack->PropertyName); ?></td>
                    <td> <?php echo e($ppPack->SupCatId); ?></td>
                    <td> <?php echo e($ppPack->CatId); ?></td>
                    <td> <?php echo e($ppPack->SubCatId); ?></td>
                    <td> <?php echo e($ppPack->ObjCatId); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/objectdelete/'.$ppPack->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
              </table>
              </div>


          </div>

    </div>

  </section>


<script type="text/javascript">

$(document).ready(function(){


  $( "#supercategory" ).change(function() {
    var superecatkey = $("#supercategory").val();
     $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':superecatkey},

          success: function(result)
          {
             $('#category').html('');
             $('#category').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
             });
          }});
  });



  $( "#category" ).change(function() {
    var catkey = $("#category").val();
     $.ajax({
          url:"<?php echo e(url('/getsubcategory')); ?>",
          method: 'GET',
          data: {'key':catkey},

          success: function(result)
          {
             $('#subcategory').html('');
             $('#subcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
             });
          }});
  });


  $( "#subcategory" ).change(function() {
    var subcateid = $("#subcategory").val();
     $.ajax({
          url:"<?php echo e(url('/getobjcat')); ?>",
          method: 'GET',
          data: {'key':subcateid},

          success: function(result)
          {
             $('#objcategory').html('');
             $('#objcategory').append('<option value="">Please select...</option>');
             
             $.each(result, function( key, value ) {
                $('#objcategory').append('<option value="'+value.id+'">'+ value.ObjectCatName +'</option>');
             });
          }});
  });




});
</script>
















<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>