<?php $__env->startSection('content'); ?>

   <!-- Section: works -->
  <section id="works" class="work" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/back6.png')); ?>)">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-8 col-lg-offset-2">
          <div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
            <div class="section-heading text-center">
              <h3 class="h-bold">Our Product</h3>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
          <div class="wow bounceInUp" data-wow-delay="0.4s">
            <div id="owl-works" class="owl-carousel">

              <?php $__currentLoopData = $workpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item workcard"><a href="<?php echo e(URL::asset($work->Work_picture)); ?>" title="<?php echo e($work->Work_desc); ?>" data-lightbox-gallery="gallery1" data-lightbox-hidpi="img/works/1@2x.jpg"><img src="<?php echo e(URL::asset($work->Work_picture)); ?>" class="img-responsive" alt="img"></a></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
          </div>
        </div>
      </div>
    </div>

  </section>
  <!-- /Section: works -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>