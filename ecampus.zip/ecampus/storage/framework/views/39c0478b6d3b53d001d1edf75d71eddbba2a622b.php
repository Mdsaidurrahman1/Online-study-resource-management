<?php $__env->startSection('content'); ?>

   <!-- Section: contact -->
  <section id="contact" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/back6.png')); ?>) "class="contact">


    
    <div class="container">
      <br>

      <div class="row marginbot-80">
        <div class="col-md-3">
          <img src="<?php echo e(URL::asset('resources/assets/img/Saidur Rahman.jpg')); ?>" style="width: 100%" alt="Saidur Rahman">
          <div class="personal">
                <h4 style="color: #fff">Saidur Rahman <br>
                <span style="font-size: 18px;"> BSc. in CSE</span></h5>
                <p>@Green  University of Bangladesh</p>
                <a href="https://www.ucepbd.org" target="_Blank"> LinkedIn Profile</a>
                <p>--------------------------------------------------</p>
                <p>md.saidur.rah5@gmail.com</p>
                <p>--------------------------------------------------</p>
                <p style="font-weight: bold;">Assistant ICT Developer</p>
                <p style="font-weight: bold;">@ UCEP Bangladesh, Since 2013</p>
                <a href="https://www.ucepbd.org" target="_Blank"> UCEP Bangladesh</a>
                <p>--------------------------------------------------</p>
                <p style="font-weight: bold;"><u>Contact no</u></p>
                <p>01723-705472 <span style="font-weight: bold;"> & </span> 01852-012518</p>
                <p style="font-weight: bold;"><u>Present Location</u></p>
                <p>779 West Kazipara, Mirpur, Dhaka, Bangladesh</p>
                <p style="font-weight: bold;"><u>Permanent Address</u></p>
                <p>Noniyagari, Palashbari, Gaibandha</p>
                <p>--------------------------------------------------</p>
                <p style="font-weight: bold;"><u>Date of Birth</u></p>
                <p>1st January 1991</p>
                <p style="font-weight: bold;"><u>Maritual Status</u></p>
                <p>Marraid since 2015</p>
                <p style="font-weight: bold;"><u>NID Number</u></p>
                <p>19913216785000450</p>
                <p style="font-weight: bold;"><u>Religion</u></p>
                <p>Islam</p>
                <p style="font-weight: bold;"><u>Language</u></p>
                <p>Bangla & English</p>
                <p>--------------------------------------------------</p>
          </div>
        </div>

        <div class="col-md-9 ">
              <div class="summary">
          <p>
          In this time I want developing my skill and experience for digital world. With my skills, ideas and knowledge I want to make a different solution, so I am searching the lab for doing this. That only one solution will solve many problem in the world. From my previous life I learnt about my ideas that is, which I thinked all now are in present. Now I am confident about my ideas, skills and me, my ideas are not just thinking but it can change the system of living if I implement it. Please think me for your business, and choose me as a new web engineer, Thanks.......
          </p>
          </div>
            <div class="addressloc">

          

          <span style="color: #690b0b; font-size: 18px;">
            <br><h3>Eduction</h3>
            <table class="table table-condensed" >
                    <tr>
                      <th>Degree </th>
                      <th>Institute</th>
                      <th>Duration</th>
                      <th>Areas of skills</th>
                    </tr>
                    <tr>
                      <td>B.Sc in CSE</td>
                      <td>Green University of Bangladesh</td>
                      <td>4 years</td>
                      <td>Programming and Newtorking</td>
                    </tr>
                    <tr>
                      <td>Diploma in Engineering</td>
                      <td>Rangpur Polytechnic Institute</td>
                      <td>4 years</td>
                      <td>Programming and Newtorking</td>
                    </tr>
                  </table>
          </span>

          <div class="divider"></div>

          <span style="color: #690b0b; font-size: 18px;">
            <br><h3>Training</h3>
                <table class="table table-condensed" >
                    <tr>
                      <th>Training </th>
                      <th>Institute</th>
                      <th>Duration</th>
                      <th>Learing Technologies</th>
                    </tr>
                    <tr>
                      <td>Professional Application Development with ASP.Net MVC</td>
                      <td>BITM (BASIS Institute of Technology and Managemrnt)</td>
                      <td>36 hours</td>
                      <td>ASP.net MVC, MSSQL Server2012, Entity Framework</td>
                    </tr>
                    <tr>
                      <td>Web App Development with PHP (Codeigniter & Laravel Framework)</td>
                      <td>New Horizon Computer Learning Center, CTG</td>
                      <td>40 Hours</td>
                      <td>PHP, PHP framework (Codeigniter & Laravel Framework), MySql, Javascript, Jquery, Bootstrap</td>
                    </tr>
                  </table>
          </span>

          <div class="divider"></div>

          <span style="color: #690b0b; font-size: 18px;">
            <br><h3>Knowledge</h3>
              <table class="table table-bordered" >
                    <tr>
                      <th>Programming Language</th>
                      <th>Database</th>
                      <th>Application</th>
                      <th>Scripting Lang</th>
                      <th>Development </th>
                    </tr>
                    <tr>
                      <td>C, C# (ASP.Net MVC)</td>
                      <td>MS SQL Server 2012</td>
                      <td>Visula Studio 2013</td>
                      <td>VUE.Js</td>
                      <td>SDLC Knowledge</td>
                    </tr>
                    <tr>
                      <td>Java</td>
                      <td>Oracle 11g</td>
                      <td>Adobe Creative Suite 6.0</td>
                      <td>ActionScript 3.0</td>
                      <td>Repository Pattern</td>
                    </tr>
                    <tr>
                      <td>PHP (Codeigniter & Laravel Framework)</td>
                      <td>MySql</td>
                      <td>Office 2013</td>
                      <td></td>
                      <td>UI, Graphics and Animation</td>
                    </tr>
                  </table>
          </span>

          <div class="divider"></div>

          <span style="color: #690b0b; font-size: 18px;">
            <br><h3>Experties</h3>
            <table class="table table-condensed responsive" >
                    <tr>
                      <th>Level of experties</th>
                      <th>Technologies (Framwork)</th>
                      <th>Database System</th>
                      <th>Programming Language</th>
                      <th>Development Experience</th>
                    </tr>
                    <tr>
                      <td>High</td>
                      <td>PHP Laravel</td>
                      <td>MySql</td>
                      <td>C, C# & PHP</td>
                      <td>Web Application</td>
                    </tr>
                    <tr>
                      <td>Medium</td>
                      <td>ASP.Net MVC & Codeigniter</td>
                      <td>MS SQL Server</td>
                      <td>Java</td>
                      <td>Desktop Application</td>
                    </tr>
                    <tr>
                      <td>Knowledge</td>
                      <td>Python Django</td>
                      <td>Oracle 11g</td>
                      <td>Python</td>
                      <td>Mobile Apps</td>
                    </tr>
                  </table>
          </span>

          <div class="divider"></div>

          <span style="color: #690b0b; font-size: 18px;">
            <br><h3>Project</h3>
                <table class="table table-condensed responsive" >
                    <tr>
                      <th>Title</th>
                      <th>Technologies Used</th>
                      <th>Refferences</th>
                      <th>Description</th>
                    </tr>
                    <tr>
                      <td>Web Application useing PHP</td>
                      <td>PHP Codeigniter</td>
                      <td><a href="http://www.dcpi.edu.bd">www.dcpi.edu.bd</a> </td>
                      <td>This project has been developed for testing base for someone my friend request</td>
                    </tr>
                    <tr>
                      <td>Web Application useing ASP.Net MVC</td>
                      <td>ASP.Net MVC, MSSQL Server 2012, Entity Framework</td>
                      <td><a href="http://www.hesheba.bd">Business Site</a></td>
                      <td>BITM Course required project</td>
                    </tr>
                    <tr>
                      <td>Graphics Design</td>
                      <td>Photoshop, Illustration, Flash</td>
                      <td><a href="https://drive.google.com/drive/folders/0B7x3ymfCBILvVnlQcDVuTTd0a1k">Designing work</a></td>
                      <td>Book Illustration and development of digital learing content for students</td>
                    </tr>
                  </table>
          </span>

<div class="divider"></div>


          <br>
          </div>
        </div>
      </div>


    </div>
  </section>
  <!-- /Section: contact -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>