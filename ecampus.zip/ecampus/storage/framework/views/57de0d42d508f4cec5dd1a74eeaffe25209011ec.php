<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">


            <p class="subtitle" > <?php echo e(Session::get('username')); ?><br>
             <?php echo e(Session::get('userrole')); ?> <br>
             <?php echo e(Session::get('institution')); ?> 
           </p>
            <a href="" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Profile</a> 
          </div>

          <div class="col-md-10">




            <div class="row">
              <div class="col-md-4">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Assignment</div>
                  <div class="panel-body">

                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">ID</th>
                              <th scope="col">Title</th>
                              <th scope="col">Deadline</th>
                          </tr>
                        </thead>
                          <tbody>
                            <tr>
                              
                            </tr>
                              <td >CSE101-bd</td>
                              <td >Class Test</td>
                              <td >15 March</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Detail</a></td>

                            </tr>
                          </tr>
                              <td >CSE101-bd</td>
                              <td >Presentation</td>
                              <td >20 March</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Detail</a></td>

                            </tr>
 <!--                              <?php $i = 1 ?>
                                <?php $__currentLoopData = $mealdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mealentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                  <td> <?php echo e($mealentity->meal_date); ?></td>
                                  <td> <?php echo e($mealentity->person); ?></td>
                                  <td><?php echo e($mealentity->meal_amount); ?></td>
                                  <td style="text-align: right;">
                                  </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>


                <div class="col-md-4">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Joined Class</div>
                  <div class="panel-body">
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#myModal"> Search Class</button> <hr>

                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Class ID</th>
                              <th scope="col">Subject</th>
                              <th scope="col">Semester</th>
                              <th scope="col" style="width: 30%; text-align: left;">Status</th>
                          </tr>
                        </thead>
                          <tbody>
 <!--                              <?php $i = 1 ?>
                                <?php $__currentLoopData = $mealdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mealentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                  <td> <?php echo e($mealentity->meal_date); ?></td>
                                  <td> <?php echo e($mealentity->person); ?></td>
                                  <td><?php echo e($mealentity->meal_amount); ?></td>
                                  <td style="text-align: right;">
                                  </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>




              <div class="col-md-4">
                  <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Resources Library</div>
                  <div class="panel-body"><!-- 
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#Acc"> Make Payment</button> <hr>
             -->        
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Resource ID</th>
                              <th scope="col">Subject</th>
                              <th scope="col">Topic</th>
                              <th scope="col">Doc Type</th>
                          </tr>
                        </thead>

                          <tbody>
                              <td >CSE101-bd</td>
                              <td >Java Lang</td>
                              <td >Class Dec.</td>
                              <td >PDF</td>
                              <td ><a href="" class="btn btn-sm btn-info"> Read</a></td>





<!--                               <?php $i = 1 ?>
                                <?php $__currentLoopData = $accdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                  <td> <?php echo e($accentity->acc_date); ?></td>
                                  <td> <?php echo e($accentity->account_name); ?></td>
                                  <td><?php echo e($accentity->payment_amount); ?></td>
                                  <td style="text-align: right;">
                                  </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                          </tbody>
                        </th>
       
                      </table>
                  </div>
                </div>
              </div>
            </div>









          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Un Joined Class</h4>
      </div>
      <div class="modal-body">
        <br>
        
        <form action="<?php echo e(route('mealpost')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
          <table class="table">
            <input type="hidden" name="memberid" value="<?php echo e(Session::get('id')); ?>">
            <input type="hidden" name="person" value="<?php echo e(Session::get('username')); ?>">

            <tr>
             <td> <label> Start Date </label></td>
             <td> <input type="date" name="meal_date"></td>
            </tr>

            <tr>
             <td> <label> Department </label></td>
             <td> <input type="text" name="meal_date"></td>
            </tr>


            <tr>
             <td> <label> Professor</label></td>
             <td> <input type="text" name="meal_date"></td>
            </tr>


            <tr>
             <td> <label> Subject</label></td>
             <td> <input type="text" name="meal_date"></td>
            </tr>

            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Post"></td>
            </tr>
          </table>
         
          
        </form>
      </div>
    </div>
  </div>
</div>







 <!-- Modal -->
<div id="Acc" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Make Payment</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
        <form action="<?php echo e(route('accpost')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
          <input type="hidden" name="member_id" value="<?php echo e(Session::get('id')); ?>">
          <input type="hidden" name="respose_person" value="<?php echo e(Session::get('username')); ?>">
          <input type="hidden" name="account_type" value="Credit">
          <table class="table">
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="acc_date"></td>
            </tr>
             <tr>
             <td> <label> Accounts name</label></td>
             <td> 
                  <select name="account_name">
                    <option> Select Name</option>
                    <option> Member Subs. Fee</option>
                    <option> Service Charge</option>
                  </select>
             </td>
           </tr>
            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="" name="payment_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>