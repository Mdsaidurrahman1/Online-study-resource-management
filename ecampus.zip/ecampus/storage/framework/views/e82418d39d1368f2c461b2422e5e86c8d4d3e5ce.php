<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">


            <p class="subtitle" > <?php echo e(Session::get('username')); ?><br>
             <?php echo e(Session::get('userrole')); ?> <br>
             <?php echo e(Session::get('institution')); ?> 
           </p>
            <a href="<?php echo e(route('memberdashboard')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Deshboard</a> 
          </div>

          <div class="col-md-10">
            <h4> <?php echo e($resouce[0]->class_id); ?> Class Detail</h4>




            <div class="row">


                <div class="col-md-6">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading"> All Class Resource</div>
                  <div class="panel-body">
                                  
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col">Semester</th>
                              <th scope="col">Schedule</th>
                              <th scope="col">Resource Type</th>
                              <th scope="col">Message</th>
                          </tr>
                        </thead>
                          <tbody>
                              <?php $i = 1 ?>
                              <?php $__currentLoopData = $resouce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                              <tr>
                                <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                <td><?php echo e($res->subject); ?></td>
                                <td><?php echo e($res->date); ?></td>
                                <td><?php echo e($res->type); ?></td>
                                <td><?php echo e($res->message); ?></td>
                                <td style="text-align: right;">
                                  <a href="http://localhost/ecampus/<?php echo e($res->link); ?>" class="btn btn-sm btn-danger"> View Resouce</a>
                                                 
                                </td>
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          

                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>




              <div class="col-md-5">
                  <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">All Assignment</div>
                  <div class="panel-body"><!-- 
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#Acc"> Make Payment</button> <hr>
             -->        
                      
                      <table class="table">
                        <thead>
                          <tr>
                              <th scope="col">Sl</th>
                              <th scope="col" style="width: 20%">Publish date</th>
                              <th scope="col">Subject</th>
                              <th scope="col">Message</th>
                              <th scope="col">Message</th>
                          </tr>
                        </thead>
                          <tbody>
                              <?php $i = 1 ?>
                              <?php $__currentLoopData = $assignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assginmentnotice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                              <tr>
                                <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                <td><?php echo e($assginmentnotice->posting_date); ?></td>
                                <td><?php echo e($assginmentnotice->subject); ?></td>
                                <td><?php echo e($assginmentnotice->message); ?></td>
                                <td>
                                  <a href="" class="btn btn-sm btn-danger"> Like </a>
                                </td>
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          

                          </tbody>
       
                      </table>
                </div>
              </div>
            </div>









          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>