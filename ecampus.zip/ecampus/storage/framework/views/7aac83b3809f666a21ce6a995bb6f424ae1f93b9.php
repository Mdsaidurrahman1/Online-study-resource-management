<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Link Details</p>

          </div>

          <div class="col-md-10 tail">
                <!-- <p><span style="font-size: 24px;color="red">Link Detail</span></p> -->
                <a href="<?php echo e(url('/admin')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Admin</a>
                <a href="<?php echo e(route('settingsmodule')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Setup</a>  
                <a href="<?php echo e(url('/property')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Add Property</a>
              <a href="<?php echo e(url('/webdirectory')); ?>" class="barmenubtn"><i class="fa fa-bars"> </i> Link library</a>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">
          <div class="col-md-2 menu">

                <p class="subtitle" >Link Details Entry</p>
                <form action="<?php echo e(route('addlinkref')); ?>" method="post" enctype="multipart/form-data">
                   <?php echo csrf_field(); ?>

                   <input type="hidden" name="linkId" value="<?php echo e($link->id); ?>">

                    <div class="form-group">
                      <label for="exampleInputEmail1">Select Properties</label>
                      <select class="form-control" id="category" name="propertyName">
                        <option class="Education">Select Property</option>
                        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ppt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($ppt->PropertyName); ?>"><?php echo e($ppt->PropertyName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </select>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Property value</label>
                      <input type="text" class="form-control" id="objectname" name="propertyValue" aria-describedby="emailHelp" placeholder="Enter Value">
                    </div>

                    <button type="submit" class="btn btn-primary">Save</button>
                  </form>
      
          </div>


          <div class="col-md-10">

           <div class="contentsection">

             <p> Object Entity: <span style="font-weight: bold;"><u><?php echo e($link->SiteName); ?></u></span> </p>
             <p>Object Type : <span style="font-weight: bold;"><u><?php echo e($link->SiteType); ?></u></span> </p>
             <hr>
             <div class="col-md-12">
               <p><b><?php echo e($link->SiteName); ?></b>  Properties</p> <hr>


               <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Property</th>
                    <th scope="col">Values</th>
                    <th scope="col" style="width: 30%; text-align: right;"></th>
                  </tr>
                </thead>
                <tbody>

                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $linkdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkdd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($linkdd->propertyName); ?></td>
                    <td> <?php echo e($linkdd->propertyValue); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <?php if(@$linkdd->propertyName == "URL"): ?>
                        <a href="<?php echo e($linkdd->propertyValue); ?>" target="_Blank" class="btn btn-sm btn-primary"> See </a>
                      <?php endif; ?>
                        <a href="<?php echo e(url('/objectdelete/'.$linkdd->id)); ?>" class="btn btn-sm btn-danger"> Del </a>

                      
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
                
              </table>





             </div>
            </div>
          </div>

    </div>

  </section>


<script type="text/javascript">

$(document).ready(function(){



  // $( "#supercategory" ).change(function() {
  //   var superecatkey = $("#supercategory").val();
  //    $.ajax({
  //         url:"<?php echo e(url('/getcategory')); ?>",
  //         method: 'GET',
  //         data: {'key':superecatkey},

  //         success: function(result)
  //         {
  //            $('#category').html('');
  //            $('#category').append('<option value="">Please select...</option>');
             
  //            $.each(result, function( key, value ) {
  //               $('#category').append('<option value="'+value.id+'">'+ value.CategoryName +'</option>');
  //            });
  //         }});
  // });




  // $( "#category" ).change(function() {
  //   var catkey = $("#category").val();
  //    $.ajax({
  //         url:"<?php echo e(url('/getsubcategory')); ?>",
  //         method: 'GET',
  //         data: {'key':catkey},

  //         success: function(result)
  //         {
  //            $('#subcategory').html('');
  //            $('#subcategory').append('<option value="">Please select...</option>');
             
  //            $.each(result, function( key, value ) {
  //               $('#subcategory').append('<option value="'+value.id+'">'+ value.SubCatName +'</option>');
  //            });
  //         }});
  // });







  // $( "#subcategory" ).change(function() {
  //   var subcateid = $("#subcategory").val();
  //    $.ajax({
  //         url:"<?php echo e(url('/getobjcat')); ?>",
  //         method: 'GET',
  //         data: {'key':subcateid},

  //         success: function(result)
  //         {
  //            $('#objcategory').html('');
  //            $('#objcategory').append('<option value="">Please select...</option>');
             
  //            $.each(result, function( key, value ) {
  //               $('#objcategory').append('<option value="'+value.id+'">'+ value.ObjectCatName +'</option>');
  //            });
  //         }});
  // });


});
</script>
















<?php $__env->stopSection(); ?>


   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert New Service in Business</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
    </div>
  </div>
</div>




<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>