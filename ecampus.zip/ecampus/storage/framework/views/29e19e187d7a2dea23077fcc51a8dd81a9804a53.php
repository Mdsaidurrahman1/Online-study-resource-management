<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Shuffle bootstrap 3 one page template</title>

  <!-- css -->
  <link href="<?php echo e(URL::asset('resources/assets/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(URL::asset('resources/assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(URL::asset('resources/assets/css/nivo-lightbox.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/nivo-lightbox-theme/default/default.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(URL::asset('resources/assets/css/owl.carousel.css')); ?>" rel="stylesheet" media="screen" />
  <link href="<?php echo e(URL::asset('resources/assets/css/owl.theme.css')); ?>" rel="stylesheet" media="screen" />
  <link href="<?php echo e(URL::asset('resources/assets/css/flexslider.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/animate.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('resources/assets/color/default.css')); ?>" rel="stylesheet">


  <link href="<?php echo e(URL::asset('resources/assets/css/mystyle.css')); ?>" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

  <section id="intro" class="home-slide text-light">



  <!-- Navigation -->
  <div id="navigation">
    <nav class="navbar navbar-custom" role="navigation">
      <div class="container">
        <div class="row" style="height:50px">
          <div class="col-md-2">
            <div class="site-logo">
              <a href="<?php echo e(route('root')); ?>" class="brand"><img src="<?php echo e(URL::asset('resources/assets/img/logo.png')); ?>" class="img-responsive" alt="img"></a>
            </div>
          </div>


          <div class="col-md-10">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu"><i class="fa fa-bars"></i></button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="menu">
              <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="#intro">Home</a></li>
              <!--   <li><a href="<?php echo e(route('about')); ?>">About Us</a></li> -->
                <li><a href="<?php echo e(route('service')); ?>">Services</a></li>
                <li><a href="<?php echo e(route('work')); ?>">Works</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                <?php if(Session::has('username')): ?>
                     <li><a href="<?php echo e(url('/admin')); ?>">Admin</a></li>
                     <li><a href="<?php echo e(route('signout')); ?>">Sign Out</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('userlogin')); ?>">Login</a></li>
                <?php endif; ?>
                <!-- <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>     -->
              </ul>
            </div>
            <!-- /.Navbar-collapse -->
          </div>
        </div>
      </div>
      <!-- /.container -->
    </nav>
  </div>
  <!-- /Navigation -->


  <!-- /Section: services -->





  <footer>
    <div class="container">
      <div class="row">

       <div class="col-md-4 ">
            <a href="#" class="fa face fa-facebook"></a>
            <a href="#" class="fa face fa-twitter"></a>
        </div>

        <div class="col-md-4">
          <div class="text-center">
            <h2>&copy; Washing Plant Hamim Enterprise</h2>
          </div>
        </div>



        <div class="col-md-4">
             <div class="credits">
              Designed by <a href="https://bootstrapmade.com/">Miliscript System</a>
            </div>
        </div>

      </div>
    </div>
  </footer>
  <link href="<?php echo e(URL::asset('resources/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.sticky.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.flexslider-min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.scrollTo.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.appear.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/stellar.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/wow.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/nivo-lightbox.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/custom.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/contactform/contactform.js')); ?>"></script>




</body>

</html>
