<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Service Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
            <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Admin Operation</a>
             
          </div>

          <div class="col-md-2 sideform">

            <p class="subtitle"> New Service</p>

             <form action="<?php echo e(route('servicepost')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="exampleInputEmail1">Service Name</label>
                  <input type="text" class="form-control" id="servicename" name="servicename" aria-describedby="emailHelp" placeholder="Enter Service Name">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea name="servicedesc" class="form-control"></textarea>
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Offer</label>
                  <input type="text" class="form-control" id="servicoffer" name="servicoffer" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Select picture</label>
                  <input type="file" id="servicpicutre" name="servicpicture" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
          </div>


          <div class="col-md-8">

            <p class="subtitle"> All Servicess</p>

           <div class="contentsection">
              
                  <?php if(Session::has('message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Attention!</strong> <?php echo e(Session::get('message')); ?>    
                  </div>
                  <?php endif; ?>

               <hr>

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Service</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Description</th>
                    <th scope="col">Offer</th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage Service</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $servicepack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($service->Service_name); ?></td>
                    <td> <img src="<?php echo e(URL::asset($service->service_picture)); ?>" style="width: 100px;"></td>
                    <td><?php echo e($service->Service_desc); ?></td>
                    <td><?php echo e($service->Type); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/serviceupdate/'.$service->id)); ?>" class="btn btn-sm btn-warning"> Edit </a>
                      <a href="<?php echo e(url('/servicedelete/'.$service->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



<?php $__env->stopSection(); ?>






<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>