<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      
      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-3 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-9 tail">
                <p><span style="font-size: 24px;color="red"> Message Management</span></p>
          </div>
        </div>
      </div>
<i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-3 menu">
              <a href="<?php echo e(route('admin_news')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Message</a> 
              <a href="<?php echo e(route('admin_service')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-home"> </i> Service</a> 
              <a href="<?php echo e(route('admin_work')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Work</a> 
              <a href="<?php echo e(route('admin_content')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Content Management</a>
             
          </div>

          <div class="col-md-9">

           <div class="contentsection">

              <table class="table table-sm table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Sender</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Type</th>
                    <th scope="col">Message</th>
                    <th scope="col">Time</th>
                    <th scope="col" style="text-align: right;">Manage message</th>
                  </tr>
                </thead>
                <tbody>

                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($msg->Sender_name); ?></td>
                    <td> <?php echo e($msg->Message_subject); ?></td>
                    <td><?php echo e($msg->Sender_email); ?> <br><?php echo e($msg->Sender_contact); ?></td>
                    <td><?php echo e($msg->Type); ?></td>
                    <td><?php echo e($msg->Message); ?></td>
                    <td><?php echo e($msg->created_at); ?></td>
                    <td style="text-align: right;">
                      <a href="<?php echo e(url('/messagedelete/'.$msg->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>



<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>