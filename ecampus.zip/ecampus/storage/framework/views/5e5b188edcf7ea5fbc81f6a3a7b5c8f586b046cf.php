<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
            <a href="<?php echo e(route('accounts')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Account Detail</a> 
            <a href="<?php echo e(route('mealmanage')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"></i> Meal Management</a> 
            <a href="<?php echo e(route('bazarmanage')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Bazar Management</a>
          </div>
          <div class="col-md-3">
            <p class="subtitle"> Bazar Register</p>

             <form action="<?php echo e(route('bazarpost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
  
                <table class="table" style="border: 0px;">
                  <tr>
                   <td> <label> Date </label></td>
                   <td> <input type="date" class="form-control" id="date" name="bazar_date"></td>
                  </tr>
                  <tr>
                   <td> <label> Person name</label></td>
                   <td> 
                    <select name="person" class="form-control">
                      <option> Select Person</option>
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $useren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($useren->username); ?>"><?php echo e($useren->username); ?> </option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                   </td>
                  </tr>


                  <tr>
                   <td> <label> Amount Tk.</label></td>
                   <td> <input type="text" class="form-control" name="tk_amount"></td>
                  </tr>
                  <tr>
                   <td> <label> Meal Count</label></td>
                   <td> <input type="" class="form-control" value="0" name="meal_amount" id="meal_amount"></td>
                  </tr>
                  <tr>
                   <td> </td>
                   <td> <input type="submit"  class="btn btn-info" name="submit" value="Assign"></td>
                  </tr>
                </table>
               
                
              </form>

          </div>
          <div class="col-md-7">
              <div class="row">
              <div class="col-md-10">
                <p class="subtitle">Daily Bazar Information</p> <hr>
                                        
                      <table class="table">
                        <thead>
                          <tr>
                            <th>Sl</th><th>Date</th><th>Person</th><th>Meal Am.</th><th>Tk. Amo.</th><th>Status</th>
                          </tr>
                        </thead>
                          <tbody>
                              <?php $i = 1 ?>
                                <?php $__currentLoopData = $bazar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bazarentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                  <td> <?php echo e($bazarentity->bazar_date); ?></td>
                                  <td> <?php echo e($bazarentity->person); ?></td>
                                  <td><?php echo e($bazarentity->meal_amount); ?></td>
                                  <td><?php echo e($bazarentity->tk_amount); ?></td>
                                  <td><?php echo e($bazarentity->bazar_status); ?></td>
                                  <td style="text-align: right;">
                                   
                                  </td>
                                </tr>
<!--  <a href="<?php echo e(url('/messagedelete/'.$bazarentity->id)); ?>" class="btn btn-sm btn-danger"> Manage </a> -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </th>
       
                      </table>

              </div>
            </div>





        


          </div>

    </div>

  </section>
  <!-- /Section: services -->

<script type="text/javascript">


  $( "#addtbn" ).hide() ;
  $('#accEndDate').hide() ;
  $( "#account_type" ).hide();

$(document).ready(function(){


     var totalDebitAmount=0;
     var totalCreditAmount=0;

     $( "#date" ).change(function() {

        var date = $("#date").val();

         $.ajax({
          url:"<?php echo e(url('/mealcount')); ?>",
          method: 'GET',
          data: {'date':date},
            
          success: function(data)
          {
              $('#meal_amount').val(data);
          },
        });



  });

});
</script>

















<?php $__env->stopSection(); ?>






<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Daily Bazar Register</h4>
      </div>
      <div class="modal-body">

       
      </div>
    </div>
  </div>
</div>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>