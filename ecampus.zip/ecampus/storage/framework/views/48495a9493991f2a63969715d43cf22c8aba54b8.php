      


<?php $__env->startSection('content'); ?>
    <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      


      <div class="row dashboardtitle">
        <div class="">
          <div class="col-md-2 head">
                <p>Admin Dashboard</p>
          </div>

          <div class="col-md-10 tail">
                <p><span style="font-size: 24px;color="red"> Category Setup Info Management</span></p>
          </div>
        </div>
      </div>
    

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
              <a href="<?php echo e(route('settingsmodule')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Setup Module</a>  
          </div>

          <div class="col-md-3 sideform">
            <p class="subtitle" > New Category</p>
            <form action="<?php echo e(route('categorypost')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label for="exampleInputPassword1">Supper Category </label>
                    <select class="form-control" id="supercategory" name="SuperCateId" >
                      <option> Select Super Category</option>
                        <?php $__currentLoopData = $supcatpack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->SuperCateName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Category Name </label>
                  <input type="text" class="form-control" id="servicoffer" name="CategoryName" aria-describedby="emailHelp" placeholder="Applicable offer">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Category Description</label>
                  <textarea name="CategoryDesc" class="form-control"></textarea>
                </div>

               <div class="form-group">
                  <label for="exampleInputEmail1">Category Type</label>
                  <select class="form-control" id="servicoffer" name="CategoryType">
                    <option value=""> Select Type</option>
                    <option value="Physical"> Physical</option>
                    <option value="Logical"> Logical</option>
                    <option value="Virtual"> Virtual</option>
                  </select>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
              </form>

          </div>

          <div class="col-md-7">

           <div class="contentsection">


             <p style="padding: 15px 2px; font-size: 32px; font-weight: bold;"> All Category info</p>

              <table class="table table-sm table-hover" id="categorytable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category Name</th>
                    <th scope="col">Category Description</th>
                    <th scope="col">Category Type </th>
                    <th scope="col" style="width: 30%; text-align: right;">Manage </th>
                  </tr>
                </thead>
                <tbody>                              
                  <?php $i = 1 ?>
                  <?php $__currentLoopData = $categorypack; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scatpack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                    <td> <?php echo e($scatpack->CategoryName); ?></td>
                    <td> <?php echo e($scatpack->CategoryDesc); ?></td>
                    <td><?php echo e($scatpack->CategoryType); ?></td>
                    <td style="width: 30%; text-align: right;">
                      <a href="<?php echo e(url('/categorydelete/'.$scatpack->id)); ?>" class="btn btn-sm btn-danger"> Delete </a>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              </div>


          </div>

    </div>

  </section>






<script type="text/javascript">


  $( "#addtbn" ).hide() ;

$(document).ready(function(){



  $( "#supercategory" ).change(function() {
  var supcatid = $("#supercategory").val();

         $.ajax({
          url:"<?php echo e(url('/getcategory')); ?>",
          method: 'GET',
          data: {'key':supcatid},
            
          success: function(data)
          {
            $('#categorytable').html('');
            
            $('#categorytable').append('<thead><tr><th scope="col">#</th><th scope="col">Category Name</th><th scope="col">Category Desc</th><th scope="col">Category type</th></tr></thead><tbody>');

             $.each(data, function( key, value ) 
             {
              $('#categorytable').append('<tr><td scope="row">'+ ++key +'</td>                    <td> '+ value.CategoryName +'</td>        <td> '+ value.CategoryDesc +'</td>        <td>'+ value.CategoryType +'</td></td>    </tr>');
              });
             $('#categorytable').append('</tbody>');
          },
        });


  });



});

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>