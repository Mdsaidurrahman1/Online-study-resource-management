<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Miliscript</title>

  <!-- css -->
  <link href="<?php echo e(URL::asset('resources/assets/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(URL::asset('resources/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(URL::asset('resources/assets/css/nivo-lightbox.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/nivo-lightbox-theme/default/default.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(URL::asset('resources/assets/css/owl.carousel.css')); ?>" rel="stylesheet" media="screen" />
  <link href="<?php echo e(URL::asset('resources/assets/css/owl.theme.css')); ?>" rel="stylesheet" media="screen" />
  <link href="<?php echo e(URL::asset('resources/assets/css/flexslider.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/animate.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(URL::asset('resources/assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('resources/assets/color/default.css')); ?>" rel="stylesheet">

  <script src="<?php echo e(URL::asset('resources/assets/js/jquery-3.3.1.js')); ?>"></script>
  <link href="<?php echo e(URL::asset('resources/assets/css/mystyle.css')); ?>" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


<!-- 
  <div class="title"> 
    <div class="container">
        <button href="https://www.facebook.com/pg/%E0%A6%AB%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%A8%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B0-%E0%A6%B0%E0%A6%BF%E0%A6%AA%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%82-%E0%A6%B8%E0%A7%87%E0%A6%A8%E0%A7%8D%E0%A6%9F%E0%A6%BE%E0%A6%B0-%E0%A6%8F%E0%A6%A8%E0%A7%8D%E0%A6%A1-%E0%A6%B9%E0%A7%8B%E0%A6%AE-%E0%A6%B8%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%AD%E0%A6%BF%E0%A6%B8-%E0%A6%A2%E0%A6%BE%E0%A6%95%E0%A6%BE-%E0%A6%B8%E0%A6%BF%E0%A6%9F%E0%A6%BF-239599890168350/posts/?ref=page_internal" class="social"><span style="color: #416ae1; font-weight: bold;">f</span></button>
        <a href="" class="social"><span style="color: red; font-weight: bold;"> YouTube </span></a>
        <button  class="btn"><a href="#" class="fa fa-facebook"></a></button>
Home and Office cleaning Service
    </div>
  </div>
 -->



  <!-- Navigation -->
  <div id="navigation" style="background-image:url(<?php echo e(URL::asset('resources/assets/img/back5.png')); ?>)">
    <nav class="navbar navbar-custom" role="navigation">
      <div class="container">
        <div class="row" >
          <div class="col-md-2">
            <div class="site-logo">
              <a href="<?php echo e(route('root')); ?>" class="brand"><img src="<?php echo e(URL::asset('resources/assets/img/logo.png')); ?>" class="img-responsive" alt="miliscript"></a>
            </div>
          </div>


          <div class="col-md-10">

            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu"><i class="fa fa-bars"></i></button>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="menu">
              <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="<?php echo e(route('root')); ?>">Home</a></li>

              <!--   <li><a href="<?php echo e(route('about')); ?>">About Us</a></li> -->
                <li><a href="<?php echo e(route('service')); ?>">Services</a></li>
                <li><a href="<?php echo e(route('product')); ?>">Product</a></li>
               
               <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                <?php if(Session::has('username')): ?>
                     <li><a href="<?php echo e(url('/admin')); ?>">Admin</a></li>
                     <li><a href="<?php echo e(route('signout')); ?>">Sign Out</a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('userlogin')); ?>">Login</a></li>
                <li><a href="<?php echo e(route('userregister')); ?>">Register</a></li>

                <?php endif; ?>
                
                <!-- <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>     -->
              </ul>
            </div>
            <!-- /.Navbar-collapse -->

          </div>
        </div>
      </div>
      <!-- /.container -->
    </nav>
  </div>
  <!-- /Navigation -->


 <section id="intro" class="home-slide text-light">


   

  <?php echo $__env->yieldContent('content'); ?>



  <footer>
    <div class="container">
      <div class="row footerset">

       <div class="col-md-6">
              <p>Our servicess</p><hr>
              <ul>
                <li>Customize Software Development</li>
                <li>Web Application Development</li>
                <li>Graphics Design</li>
                <li>Digital Education Content Development</li>
                <li>Inclusive Training</li>
                <li>Consultation</li>
              </ul>
        </div>

        <div class="col-md-6">
          <div class="text-center">
            <p> Office Address</p><hr>
            
            <p><span style="font-weight:bold; font-size: 40px; color: #dabdbd;"><i>miliscript</i></span>
            <p><span style="font-weight:bold;">Micro Intelligence of Life relevant Investigation</span> <br>
            West Kazipara, Dhaka<br>
            </p>
            <hr>
            All rights reserved by : <a href="https://miliscript.com/">Miliscript System</a>
          </div>
        </div>

      </div>
    </div>
  </footer>
  <link href="<?php echo e(URL::asset('resources/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

  <script src="<?php echo e(URL::asset('resources/assets/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.sticky.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.flexslider-min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.scrollTo.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/jquery.appear.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/stellar.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/wow.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/nivo-lightbox.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/js/custom.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('resources/assets/contactform/contactform.js')); ?>"></script>




</body>

</html>
