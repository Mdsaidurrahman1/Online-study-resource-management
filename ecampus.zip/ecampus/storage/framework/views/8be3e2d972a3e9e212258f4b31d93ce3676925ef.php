<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="login" class="login">
    <div class="container marginbot-50">
      <div class="row">
        <div class="col-lg-5 col-lg-offset-2 loginform" >

          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>




            <h2> Member Register form</h2>  
                  <?php if(Session::has('message')): ?>
                     <div class="alert alert-warning"><?php echo e(Session::get('message')); ?></div>
                  <?php endif; ?>
              <form action="<?php echo e(route('registerpost')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="" value="">


                <input type="hidden" class="form-control" id="exampleInputEmail1" name="role" value="Member" aria-describedby="emailHelp" >

                <div class="form-group">
                  <label for="exampleInputEmail1">Frist Name</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="first_name" aria-describedby="emailHelp" placeholder="Enter first name">
                </div>

                 <div class="form-group">
                  <label for="exampleInputEmail1">Last Name </label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="last_name" aria-describedby="emailHelp" placeholder="Enter last name">
                </div>



                <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="username" aria-describedby="emailHelp" placeholder="Enter user name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Date of Birth</label>
                  <input type="date" class="form-control" id="exampleInputEmail1" name="date_of_birth" aria-describedby="emailHelp" placeholder="">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Institution name</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="institution" aria-describedby="emailHelp" placeholder="Enter institution name">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">User Role</label>
                  <select class="form-control" name="user_role" >
                    <option value=""> Select Role</option>
                    <option value="Student"> Student</option>
                    <option value="Professor"> Professor</option>
                    <option value="Advisor"> Advisor</option>
                  </select>
                  <input type="text" id="exampleInputEmail1"  aria-describedby="emailHelp" placeholder="Enter user name">
                </div>









                <div class="form-group">
                  <label for="exampleInputEmail1">Contact No</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="contact_no" aria-describedby="emailHelp" placeholder="Enter contact No">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Email</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" class="form-control" id="exampleInputEmail1" name="password" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

               <br><input type="submit" class="btn btn-info"value="Register">
                <br>

              </form>


        </div>
        <div class="col-lg-4 col-lg-offset-2">
            
        </div>
        <div class="col-lg-4 col-lg-offset-2">

        </div>
      </div>

    </div>


  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>