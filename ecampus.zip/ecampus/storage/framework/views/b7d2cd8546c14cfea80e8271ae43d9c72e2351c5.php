<?php $__env->startSection('content'); ?>

  <!-- Section: services -->
  <section id="admindashboard" class="admindashboard">
      

    <i class="fab fa-audible"></i>

    <div class="row">

          <div class="col-md-2 menu">
            <a href="<?php echo e(route('accounts')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Account Detail</a> 
            <a href="<?php echo e(route('mealmanage')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"></i> Meal Management</a>
            <a href="<?php echo e(route('bazarmanage')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Bazar Management</a> 
            <a href="<?php echo e(route('admin')); ?>" class="btn btn-info btn-sm menubtn"><i class="fa fa-bars"> </i> Dashboard</a> 



          </div>

          <div class="col-md-10">
             <p class="subtitle" > Meal Management_ Dashboard  </p> <hr>

              <div class="row">
              <div class="col-md-8">

                <div class="panel panel-primary">
                  <!-- Default panel contents -->
                  <div class="panel-heading">Daily Meal Management</div>
                  <div class="panel-body">
                    
                    <h6>Meal Detail</h6>
                      <table class="table">
                        <thead>
                          <tr>
                            <th>Sl</th><th>Date</th><th>Person</th><th>Meal Amount</th>
                          </tr>
                        </thead>
                          <tbody>
                              <?php $i = 1 ?>
                                <?php $__currentLoopData = $mealdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mealentity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td scope="row">  <?php echo  $i++ ;  ?>  </td>
                                  <td> <?php echo e($mealentity->meal_date); ?></td>
                                  <td> <?php echo e($mealentity->person); ?></td>
                                  <td><?php echo e($mealentity->meal_amount); ?></td>
                                  <td style="text-align: right;">
                                   
                                  </td>
                                </tr>
<!--  <a href="<?php echo e(url('/messagedelete/'.$mealentity->id)); ?>" class="btn btn-sm btn-danger"> Manage </a> -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
       
                      </table>
                  </div>
                </div>

              </div>
            </div>










          </div>

    </div>

  </section>
  <!-- /Section: services -->


<?php $__env->stopSection(); ?>


<!-- Modal -->
<div id="myModalaccount" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Account Entry</h4>
      </div>
      <div class="modal-body">

        <form action="<?php echo e(route('accpost')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
        <form>
          <table class="table">
            <tr>
             <td> <label> Person name</label></td>
             <td> 
              <select name="account_type">
                <option> Select Type</option>
                <option> Debit</option>
                <option> Credit</option>
              </select>
             </td>
            </tr>
            <tr>
             <td> <label> Name</label></td>
             <td> <input type="text" name="account_name"></td>
            </tr>
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="acc_date"></td>
            </tr>
            <tr>
             <td> <label> Responsible Person </label></td>
             <td> <input type="text" name="respose_person"></td>
            </tr>

            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="text" name="payment_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>

        </form>
      </div>
    </div>
  </div>
</div>





<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Daily Bazar Register</h4>
      </div>
      <div class="modal-body">

        <form action="<?php echo e(route('bazarpost')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
        <form>
          <table class="table">
            <tr>
             <td> <label> Person name</label></td>
             <td> 
              <select name="person">
                <option> Select Person</option>
                <option> Saidur Rahman</option>
                <option> Rifat Hasib</option>
                <option> Alamin</option>
              </select>
             </td>
            </tr>
            <tr>
             <td> <label> Date </label></td>
             <td> <input type="date" name="bazar_date"></td>
            </tr>
            <tr>
             <td> <label> Meal Count</label></td>
             <td> <input type="" name="meal_amount"></td>
            </tr>
            <tr>
             <td> <label> Amount Tk.</label></td>
             <td> <input type="text" name="tk_amount"></td>
            </tr>
            <tr>
             <td> </td>
             <td> <input type="submit" name="submit" value="Submit"></td>
            </tr>
          </table>
         
          
        </form>
      </div>
    </div>
  </div>
</div>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>