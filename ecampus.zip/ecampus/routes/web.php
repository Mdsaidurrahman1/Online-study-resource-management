<?php
// Auth::routes();

//**********************************************************************
// ------------------- Home Site Basic Route ---------------------------
//====================----------------------============================

Route::get('/','HomeController@index')->name('root');
Route::get('/about','HomeserviceController@companydetail')->name('about');
Route::post('/usermessage','MessageController@messagepost')->name('usermessage');


//**********************************************************************
// ------------------ User releted Route -------------------------------
//====================----------------------============================

//--- user management --------------------------------
Route::get('/login','UserController@login')->name('userlogin');
Route::get('/register','UserController@register')->name('userregister');
Route::post('/loginpost', 'UserController@loginpost')->name('loginpost');
Route::post('/registerpost', 'UserController@registerpost')->name('registerpost');


//--- order management --------------------------------





Route::group(['middleware'=>'preventback'], function()
{
	Route::get('/signout', 'UserController@signout')->name('signout');
});

//**********************************************************************
// ------------------------ Secure Route -------------------------------
//====================----------------------============================

Route::group(['middleware'=>'checkauthencation'], function()
{
	Route::get('/admin', 'AdminController@admin')->name('admin');
	Route::get('/memberdashboard', 'MemberController@dashboard')->name('memberdashboard');


	// Bazar Management
	//Route::post('/bazarpost', 'BazarController@bazerPost')->name('bazarpost');
	//Route::get('/bazarmanage', 'BazarController@bazarmanage')->name('bazarmanage');

	//Route::get('/bazarregister', 'BazarController@bazarregister')->name('bazarregister');
	//Route::get('/getbazaramount', 'BazarController@monthlybazar')->name('getbazaramount');
	
	Route::get('/addresource', 'ResourceController@Resource')->name('addresource');
	Route::get('/addassignment', 'AssignmentController@AssignmentPost')->name('addassignment');
	Route::post('/publishssignment', 'AssignmentController@Assignmentpublish')->name('publishssignment');



	Route::post('/addnewresource', 'ResourceController@ResourcePost')->name('addnewresource');

		// Class Management
	
	Route::post('/addclass', 'ClassController@ClassPost')->name('addclass');
	Route::post('/joinclass', 'StudentClassController@JoinClass')->name('joinclass');





	Route::get('/classdetail/{cid}', 'ClassController@ClassDetail')->name('classdetail');

		// Route::get('/objectdetail/{id}', 'ObjectController@detail')->name('objectdetail');

	//Route::post('/mealpost', 'MealController@MealPost')->name('mealpost');
	//Route::get('/mealmanage', 'MealController@mealmanage')->name('mealmanage');
	//Route::get('/mealcount', 'MealController@mealcounter')->name('mealcount');





		// Account Management
	//Route::post('/accpost', 'AccountController@accountPost')->name('accpost');
	//Route::post('/debitaccounts', 'AccountController@accdebitPost')->name('debitaccounts');
	//Route::get('/accounts', 'AccountController@account')->name('accounts');
	//Route::get('/monthendacc', 'AccountController@monthaccount')->name('monthendacc');

	//Route::get('/getaccounts', 'CalculationController@getaccounts')->name('getaccounts');





});











